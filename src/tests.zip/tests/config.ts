export const mockEndpoint = 'http://localhost:8701/';
